const apiKey = '&appid=c279be3ec44a9d9a289b9409a8fda5ad&units=imperial';
const serverUrl = 'http://localhost:3000';
const baseURL = 'http://api.openweathermap.org/data/2.5/weather?zip=';

const formData = document.querySelector('.appform');

 

const getWeatherData = async (zipCode) => {
  // res equals to the result of fetch function
  const res = await fetch(baseURL + zipCode + apiKey);
  try {
   
    const userData = await res.json();
    return userData;
  } catch (error) {
    console.log("error", error);

  }
};


document.getElementById('generate').addEventListener('click', performAction);

function performAction(e) {
  let d = new Date();
  let newDate = (d.getMonth() + 1) + '.' + d.getDate() + '.' + d.getFullYear();
  

  e.preventDefault();

  const zipCode = document.getElementById('zip').value;
  const contentData = document.getElementById('feelings').value;

try {
  getWeatherData(zipCode)
    .then(function (userData) {
      postData('/add', { date: newDate, temp: userData.main.temp, content: contentData }).then(function (newData) {
          retrieveData()
      }).catch(function (error) {
        console.error("Error ", error);
      })
    }).finally(function () {
      formData.reset();
    });
} catch (error) {
  console.error("Error:", error);
}

}


const retrieveData = async () =>{
  const request = await fetch(serverUrl+'/all');
  
  try {


  const allData = await request.json()
  console.log(allData)
  document.getElementById('temp').innerHTML = "temp: "+Math.round(allData.temp)+
  ' degrees';
  document.getElementById('content').innerHTML ="content: "+  allData.content;
  document.getElementById("date").innerHTML ="date: "+allData.date;
  }
  catch(error) {
  console.log("error", error);
  }}


const postData = async (url = '', data = {}) => {
  try {
  const req = await fetch(serverUrl+url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      date: data.date,
      temp: data.temp,
      content: data.content
    })
  })

  
    const newData = await req.json();
    return newData;
  }
  catch (error) {
    console.log(`error post data------->${error}`);
  }
};