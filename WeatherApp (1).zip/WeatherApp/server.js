let projectData = {};


const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

app.use(cors());
app.use(express.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());



app.use(express.static('public'));

app.get('/all', getData);

app.post('/add',addData);

function getData(req, res) {
  res.send(projectData);
}

function addData(req, res) {
  projectData['date'] = req.body.date;
  projectData['temp'] = req.body.temp;
  projectData['content'] = req.body.content;
  res.send(projectData);
}




app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});


