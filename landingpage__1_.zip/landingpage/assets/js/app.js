/**
* variables
*/
  
var nav = document.querySelector("nav");  
var tabs = document.querySelectorAll("nav > ul li.tab");
var mymenu_btn = document.querySelector("nav > ul li.mymenu_btn");
var mycontent = document.querySelectorAll(".mycontent");   
var md = 720;

let nav_height = nav.clientHeight;
let nav_top_offset = offset(nav).top;

let scroll_position = 0;
let ticking = false;


// getBoundingClientRect() 
function offset(elem){
  let rect = elem.getBoundingClientRect();
  let top = rect.top + (window.pageYOffset || document.documentElement.scrollTop),
      left = rect.left + (window.pageYOffset || document.documentElement.scrollLeft),
      right = left + elem.clientWidth,
      bottom = top + elem.clientHeight;
  return { top, right, bottom, left };
}

// get view height %
function vh(v) {
  let h = Math.max(document.documentElement.clientHeight, window.innerHeight || 0);
  return (v * h) / 100;
}




// menu append function dynamic append menu acourding to sections
function appendfunction() {

var ul = document.getElementById("mylist");
var li = document.createElement("li");

li.innerHTML = '<img src="assets/icons/menu_icon.png">';
li.classList.add("mymenu_btn");
ul.appendChild(li);
li = document.createElement("li");
li.classList.add("tab");
li.classList.add("placeholder");
ul.appendChild(li);
mycontent.forEach((mypages, idx) => {
  
li = document.createElement("li");
li.append(mypages.getAttribute("name"));
//li.innerHTML = mypages.getAttribute("name");
li.setAttribute("data-text", mypages.getAttribute("name"));
li.classList.add("tab");
if(idx == 0) {
  li.classList.add("active");
}
li.setAttribute("id", "#"+mypages.getAttribute("name")); // added line
ul.appendChild(li);
});

}


window.onload=function(){
// call menu append function
appendfunction();
var nav = document.querySelector("nav");  
var tabs = document.querySelectorAll("nav > ul li.tab");
var mymenu_btn = document.querySelector("nav > ul li.mymenu_btn"); 



// add event listener for scrolling
window.addEventListener("scroll", e => {
  e.preventDefault();
  scroll_position = window.pageYOffset;
  if (!ticking) {
    window.requestAnimationFrame(() => { 
        nav.style.position = "fixed";
        nav.style.top = "0";
        nav.transition = "0.5s linear";
     
      // sections loop
      mycontent.forEach((mypages, idx) => {
        let { top, bottom }  = offset(mypages);          
        if(scroll_position>=top-nav_height && scroll_position<=bottom-nav_height){       
          let active_tab = document.querySelector("nav ul li.active");
          if(active_tab) active_tab.classList.remove("active");
          tabs[idx+1].classList.add("active");     
        }
        // call hide all tabs function
        hide_alltabs();
      })
      
      ticking = false;
    });

    ticking = true;
  }
});

// hide all tabs function
function hide_alltabs(){
  if(window.innerWidth<=md) {
    tabs.forEach(tab => {
      tab.classList.add("hidden");
    });
  }
}

// call hide all tabs function
hide_alltabs();

// screen on resize function to hide menu (tabs) on mobile view
window.onresize = e => {
  e.preventDefault();
  if(window.innerWidth<=md)
    tabs.forEach(tab => {
      tab.classList.add("hidden");
    });
  else
    tabs.forEach(tab => {
      tab.classList.remove("hidden");
    });
}

// on menu btn click function to hide or show menu (tabs)
mymenu_btn.onclick = e => {
  e.preventDefault();
  if(window.innerWidth<=md) {
    tabs.forEach(tab => {
      tab.classList.toggle("hidden");
    });
  }
}

// go to tabe content on tab cliick 
tabs.forEach(tab => {
  
tab.onclick = e => {
  e.preventDefault();
  window.location.href = tab.id;
}});

}