import { checkForName } from './js/nameChecker'
import { validUrl } from './js/checkURL'
import { handleSubmit } from './js/formHandler'
import './styles/resets.scss'
import './styles/base.scss'
import './styles/footer.scss'
import './styles/form.scss'
import './styles/header.scss'

window.addEventListener('DOMContentLoaded', (e) => {
    const submit_btn = document.getElementById("submit_btn");
    submit_btn.addEventListener('click', () => {
        //alert("clicked");
        handleSubmit(e);
        
    })
    /*let formText = document.getElementById('url').value
    alert(formText);*/
})
alert("I EXIST")
console.log("CHANGE!!");
