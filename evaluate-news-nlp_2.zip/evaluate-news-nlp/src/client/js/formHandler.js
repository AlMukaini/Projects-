import { checkForURL } from "./checkURL"
function handleSubmit(e) {
    e.preventDefault();

    // check what text was put into the form field
    let formText = document.getElementById('url').value

    if(checkForURL(formText)) {
    console.log("::: FORM INPUT VALID :::")
        
    console.log("BUILDING REQUEST");
    fetch('http://localhost:8080/api', {
        method: 'POST',
        credentials: 'same-origin',
        mode: 'cors',
        headers: {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': '*',
        },
        body: JSON.stringify({url: formText})
    })
    .then(res => res.json())
    .then(function(res) {
        // print for debugging
        console.log(res); 

        // Populate html with result
        document.querySelector('section.url-results #title').innerHTML = res.title
        document.querySelector('section.url-results #heading_list').innerHTML = res.heading_list
    })
    

    } else {
        alert('invalid URL, please try a valid URL.');
    }
}

const postData = async (url = "", data = {}) => {
    
    console.log('Analyzing:', data);
    const response = await fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        mode: 'cors',
        headers: {
        'Content-Type': 'application/json',
        },
        body: JSON.stringify(data)
    });
    try {
        
        const newData = await response.json();
        alert('Data received:', newData);
        console.log('Data received:', newData)
        return newData;
    } catch (error) {
        alert('error', error);
        console.log('error', error);
    }
};

// API response output (https://www.meaningcloud.com/developer/sentiment-analysis/doc/2.1/response)


export { handleSubmit }