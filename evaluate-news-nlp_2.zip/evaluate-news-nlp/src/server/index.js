const dotenv = require('dotenv');
dotenv.config();

//console.log(`Your API key is ${process.env.API_KEY}`);
var textapi = process.env.API_KEY;
var path = require('path')
const express = require('express')
const mockAPIResponse = require('./mockAPI.js');
const { default: axios } = require('axios');
const { error } = require('console');

const app = express()

app.use(express.static('dist'))

console.log(__dirname)

app.get('/', function (req, res) {
     res.sendFile('dist/index.html')
    //res.sendFile(path.resolve('src/client/views/index.html'))
})



/*app.get('/', function (req, res) {
    res.send(mockAPIResponse)
})*/

// Post
// POST Route
let baseURL = 'https://api.meaningcloud.com/documentstructure-1.0';
app.post('/api', async function(req, res) {
    let userInput = req.body.url;
    console.log(`You entered: ${userInput}`);
    const apiURL = `${baseURL}?key=${textapi}&url=${userInput}&lang=en`;
    //const apiURL = `${baseURL}key=${textapi}&url=${userInput}&lang=en`

    const response = await fetch(apiURL)
    const myData = await response.json()
    console.log(myData)
    res.send(myData)
    
})

// designates what port the app will listen to for incoming requests
app.listen(8000, function () {
    console.log('Example app listening on port 8000!')
})


/*var textapi = new aylien({
    //application_id: process.env.API_ID,
    application_key: process.env.API_KEY
    });*/
